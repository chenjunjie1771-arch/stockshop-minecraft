package me.stockshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;

public class StockShop extends JavaPlugin implements TabExecutor, Listener {

    // ---------------- price guessing ----------------

    private static final String[] EXACT = {
        "DRAGON_EGG=5000","BEACON=3000","NETHER_STAR=2000","ELYTRA=1500","DRAGON_HEAD=1500","MACE=1500",
        "ENCHANTED_GOLDEN_APPLE=1500","GOLDEN_APPLE=150","GOLDEN_CARROT=30","TOTEM_OF_UNDYING=800",
        "HEART_OF_THE_SEA=800","CONDUIT=900","TRIDENT=600","HEAVY_CORE=500","WITHER_SKELETON_SKULL=400",
        "NETHERITE_BLOCK=7200","NETHERITE_INGOT=800","NETHERITE_SCRAP=200","ANCIENT_DEBRIS=200",
        "DIAMOND_BLOCK=900","DIAMOND=100","EMERALD_BLOCK=540","EMERALD=60",
        "GOLD_BLOCK=225","GOLD_INGOT=25","GOLD_NUGGET=3","IRON_BLOCK=135","IRON_INGOT=15","IRON_NUGGET=2",
        "IRON_BARS=7","IRON_DOOR=30","IRON_TRAPDOOR=60","COPPER_BLOCK=36","COPPER_INGOT=4",
        "COAL_BLOCK=45","COAL=5","CHARCOAL=4","LAPIS_BLOCK=90","LAPIS_LAZULI=10",
        "REDSTONE_BLOCK=54","REDSTONE=6","QUARTZ=6","AMETHYST_SHARD=5","ENDER_PEARL=40","ENDER_EYE=60",
        "BLAZE_ROD=20","BLAZE_POWDER=10","GHAST_TEAR=60","GUNPOWDER=8","SLIME_BALL=6","SHULKER_SHELL=150",
        "PHANTOM_MEMBRANE=15","NAUTILUS_SHELL=100","ECHO_SHARD=100","BREEZE_ROD=30","WIND_CHARGE=8",
        "SPONGE=40","WET_SPONGE=40","SADDLE=100","NAME_TAG=100","ENCHANTED_BOOK=150",
        "BONE=4","STRING=3","FEATHER=3","LEATHER=6","ARROW=2","SUGAR=3","PAPER=3","BOOK=12","HONEYCOMB=6",
        "HONEY_BOTTLE=8","WHEAT_SEEDS=1","BEETROOT=2","MELON=18","COBBLESTONE=0.5","DIRT=0.5","SAND=1",
        "STONE=1","OBSIDIAN=15","CRYING_OBSIDIAN=25","TNT=40","ENDER_CHEST=150","ANVIL=120"
    };

    // First match wins. ^x = starts with, x$ = ends with, else contains
    private static final String[] RULES = {
        "DIAMOND_ORE=110","EMERALD_ORE=65","GOLD_ORE=20","IRON_ORE=12","COPPER_ORE=3","COAL_ORE=4",
        "LAPIS_ORE=8","REDSTONE_ORE=5","QUARTZ_ORE=6","_ORE$=6",
        "^NETHERITE_=1200","^DIAMOND_=250","^GOLDEN_=120","^IRON_=80","^CHAINMAIL_=90","^TURTLE_=60",
        "^LEATHER_=20","^WOODEN_=6","^RAW_=8","^COOKED_=8","^WAXED_=40","^POTTED_=1",
        "MUSIC_DISC=150","SMITHING_TEMPLATE=200","POTTERY_SHERD=40","BANNER_PATTERN=50",
        "_SKULL$=100","_HEAD$=100","HORSE_ARMOR=150","SHULKER_BOX=300",
        "_BED$=15","_WOOL$=3","_CARPET$=1","_CONCRETE$=2","_CONCRETE_POWDER$=2","_TERRACOTTA$=2",
        "_STAINED_GLASS$=2","_GLASS_PANE$=1","_LOG$=4","_WOOD$=4","_STEM$=4","_HYPHAE$=4","_PLANKS$=1",
        "_SLAB$=1","_STAIRS$=1","_WALL$=1","_FENCE$=1","_FENCE_GATE$=3","_DOOR$=3","_TRAPDOOR$=3",
        "_SIGN$=3","_BOAT$=8","_RAFT$=8","_SAPLING$=2","_LEAVES$=1","_SEEDS$=1","_DYE$=3","_BANNER$=15",
        "_CANDLE$=4","_STEW$=10","_BUTTON$=1","_PRESSURE_PLATE$=2","_SPAWN_EGG$=0"
    };
    private static final double DEFAULT_PRICE = 3.0;

    private static final String[] EXCLUDE = {
        "_SPAWN_EGG","COMMAND_BLOCK","STRUCTURE_","JIGSAW","BARRIER","BEDROCK","DEBUG_STICK",
        "KNOWLEDGE_BOOK","REINFORCED_DEEPSLATE","END_PORTAL","SPAWNER","FARMLAND","DIRT_PATH",
        "CHORUS_PLANT","BUDDING_AMETHYST","INFESTED_","FROGSPAWN","PLAYER_HEAD","WRITTEN_BOOK",
        "FILLED_MAP","TEST_BLOCK","TEST_INSTANCE","PETRIFIED_OAK_SLAB","VAULT","OMINOUS_","LIGHT","DRAGON_EGG"
    };

    // ---------------- categories ----------------

    enum Cat {
        FARMING("Farming", Material.WHEAT),
        FOOD("Food", Material.COOKED_BEEF),
        ORES("Ores & Minerals", Material.DIAMOND),
        BLOCKS("Building Blocks", Material.STONE_BRICKS),
        WOOD("Wood", Material.OAK_LOG),
        TOOLS("Tools & Combat", Material.DIAMOND_SWORD),
        REDSTONE("Redstone & Transport", Material.REDSTONE),
        MOBS("Mob Drops, Nether & End", Material.ENDER_PEARL),
        DECOR("Decoration & Dyes", Material.RED_BANNER),
        SPAWNERS("Spawners", Material.SPAWNER),
        MISC("Everything Else", Material.CHEST);
        final String label; final Material icon;
        Cat(String l, Material i) { label = l; icon = i; }
    }
    private static final int[] CAT_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22};

    private static final Set<String> ORES = Set.of("DIAMOND","EMERALD","COAL","CHARCOAL","LAPIS_LAZULI","QUARTZ",
        "AMETHYST_SHARD","NETHERITE_SCRAP","ANCIENT_DEBRIS","DIAMOND_BLOCK","EMERALD_BLOCK","GOLD_BLOCK",
        "IRON_BLOCK","COPPER_BLOCK","COAL_BLOCK","LAPIS_BLOCK","NETHERITE_BLOCK");
    private static final Set<String> FARM = Set.of("WHEAT","CARROT","POTATO","BEETROOT","MELON_SLICE","MELON",
        "PUMPKIN","SUGAR_CANE","SUGAR","BAMBOO","CACTUS","KELP","DRIED_KELP_BLOCK","NETHER_WART","COCOA_BEANS",
        "SWEET_BERRIES","GLOW_BERRIES","SEA_PICKLE","HAY_BLOCK","BONE_MEAL","HONEYCOMB","HONEY_BOTTLE","EGG",
        "BROWN_MUSHROOM","RED_MUSHROOM","PITCHER_POD","VINE","LILY_PAD");
    private static final Set<String> MOBS = Set.of("BONE","STRING","FEATHER","LEATHER","RABBIT_HIDE","RABBIT_FOOT",
        "GUNPOWDER","ENDER_PEARL","ENDER_EYE","BLAZE_ROD","BLAZE_POWDER","GHAST_TEAR","SLIME_BALL","MAGMA_CREAM",
        "SPIDER_EYE","FERMENTED_SPIDER_EYE","PHANTOM_MEMBRANE","SHULKER_SHELL","NAUTILUS_SHELL","HEART_OF_THE_SEA",
        "INK_SAC","GLOW_INK_SAC","PRISMARINE_SHARD","PRISMARINE_CRYSTALS","TURTLE_SCUTE","ARMADILLO_SCUTE",
        "BREEZE_ROD","ECHO_SHARD","NETHER_STAR","DRAGON_EGG","DRAGON_BREATH","GOAT_HORN","GLASS_BOTTLE",
        "BREWING_STAND","CAULDRON","TURTLE_EGG","SNIFFER_EGG","HEAVY_CORE","BONE_BLOCK");
    private static final Set<String> REDSTONE = Set.of("REPEATER","COMPARATOR","OBSERVER","HOPPER","DROPPER",
        "DISPENSER","DAYLIGHT_DETECTOR","TARGET","LEVER","TNT","SLIME_BLOCK","HONEY_BLOCK","TRIPWIRE_HOOK",
        "LIGHTNING_ROD","NOTE_BLOCK","JUKEBOX","CRAFTER");
    private static final String[] REDSTONE_KEYS = {"REDSTONE","PISTON","RAIL","MINECART","_BUTTON","PRESSURE_PLATE",
        "SCULK_SENSOR","COPPER_BULB"};
    private static final String[] TOOL_SUFFIX = {"_SWORD","_PICKAXE","_AXE","_SHOVEL","_HOE","_HELMET","_CHESTPLATE",
        "_LEGGINGS","_BOOTS","_HORSE_ARMOR","_BUCKET"};
    private static final Set<String> TOOLS = Set.of("BOW","CROSSBOW","TRIDENT","MACE","SHIELD","ARROW","SPECTRAL_ARROW",
        "FISHING_ROD","SHEARS","FLINT_AND_STEEL","ELYTRA","TOTEM_OF_UNDYING","SADDLE","BRUSH","SPYGLASS","COMPASS",
        "RECOVERY_COMPASS","CLOCK","BUCKET","LEAD","NAME_TAG","ENCHANTED_BOOK","FIREWORK_ROCKET","FIREWORK_STAR",
        "WIND_CHARGE","EXPERIENCE_BOTTLE");
    private static final String[] WOOD_TYPES = {"OAK","SPRUCE","BIRCH","JUNGLE","ACACIA","DARK_OAK","MANGROVE",
        "CHERRY","PALE_OAK","BAMBOO","CRIMSON","WARPED"};
    private static final String[] WOOD_SUFFIX = {"_LOG","_WOOD","_PLANKS","_STEM","_HYPHAE","_SLAB","_STAIRS",
        "_FENCE","_FENCE_GATE","_DOOR","_TRAPDOOR","_SIGN","_HANGING_SIGN","_BOAT","_RAFT","_CHEST_BOAT",
        "_CHEST_RAFT","_LEAVES","_MOSAIC"};
    private static final Set<String> WOOD_EXTRA = Set.of("STICK","CHEST","TRAPPED_CHEST","BARREL","CRAFTING_TABLE",
        "LADDER","BOOKSHELF","CHISELED_BOOKSHELF","LECTERN","COMPOSTER","LOOM","CARTOGRAPHY_TABLE",
        "FLETCHING_TABLE","SMITHING_TABLE","SCAFFOLDING","BOWL");
    private static final String[] DECOR_SUFFIX = {"_WOOL","_CARPET","_BED","_BANNER","_DYE","_CONCRETE",
        "_CONCRETE_POWDER","_TERRACOTTA","_STAINED_GLASS","_STAINED_GLASS_PANE","_CANDLE","_SHULKER_BOX","_TULIP","_ORCHID"};
    private static final String[] DECOR_KEYS = {"BANNER_PATTERN","MUSIC_DISC","POTTERY_SHERD","SMITHING_TEMPLATE","_CORAL"};
    private static final Set<String> DECOR = Set.of("SHULKER_BOX","PAINTING","ITEM_FRAME","GLOW_ITEM_FRAME","LANTERN",
        "SOUL_LANTERN","CHAIN","GLASS","GLASS_PANE","ALLIUM","AZURE_BLUET","OXEYE_DAISY","CORNFLOWER",
        "LILY_OF_THE_VALLEY","DANDELION","POPPY","ROSE_BUSH","PEONY","LILAC","SUNFLOWER","WITHER_ROSE",
        "TORCHFLOWER","FLOWER_POT","ARMOR_STAND");

    private boolean any(String n, String[] keys, boolean endsWith) {
        for (String k : keys) if (endsWith ? n.endsWith(k) : n.contains(k)) return true;
        return false;
    }

    private Cat categorize(Entry e) {
        if (e.spawner != null) return Cat.SPAWNERS;
        Material m = e.mat;
        String n = m.name();
        if (n.endsWith("_ORE") || n.endsWith("_INGOT") || n.endsWith("_NUGGET") || n.startsWith("RAW_") || ORES.contains(n)) return Cat.ORES;
        if (FARM.contains(n) || n.endsWith("_SAPLING") || n.endsWith("_SEEDS")) return Cat.FARMING;
        if (MOBS.contains(n) || n.endsWith("POTION") || n.endsWith("_SKULL") || n.endsWith("_HEAD")) return Cat.MOBS;
        if (m.isEdible()) return Cat.FOOD;
        if (REDSTONE.contains(n) || any(n, REDSTONE_KEYS, false)) return Cat.REDSTONE;
        if (TOOLS.contains(n) || any(n, TOOL_SUFFIX, true) || n.contains("_ON_A_STICK") || n.contains("TIPPED_ARROW")) return Cat.TOOLS;
        String w = n.startsWith("STRIPPED_") ? n.substring(9) : n;
        for (String t : WOOD_TYPES) if (w.startsWith(t + "_") && any(w, WOOD_SUFFIX, true)) return Cat.WOOD;
        if (WOOD_EXTRA.contains(n)) return Cat.WOOD;
        if (DECOR.contains(n) || any(n, DECOR_SUFFIX, true) || any(n, DECOR_KEYS, false)) return Cat.DECOR;
        if (n.startsWith("END_") || n.startsWith("CHORUS_") || n.contains("PURPUR") || n.contains("SOUL_")
            || n.contains("BASALT") || n.contains("BLACKSTONE") || n.contains("GLOWSTONE") || n.contains("SHROOMLIGHT")
            || n.contains("MAGMA_BLOCK") || n.endsWith("_FUNGUS") || n.endsWith("_NYLIUM") || n.endsWith("_ROOTS")
            || n.contains("WART_BLOCK") || n.contains("SCULK") || n.endsWith("_VINES")
            || (n.contains("NETHER") && !n.contains("NETHERITE"))) return Cat.MOBS;
        return m.isBlock() ? Cat.BLOCKS : Cat.MISC;
    }

    // ---------------- data ----------------

    static class Entry {
        final String key; final Material mat; final EntityType spawner;
        Entry(String key, Material mat, EntityType spawner) { this.key = key; this.mat = mat; this.spawner = spawner; }
        boolean isSpawner() { return spawner != null; }
    }

    enum Type { MAIN, BROWSE, AMOUNT }

    static class Menu implements InventoryHolder {
        final Type type; Inventory inv;
        List<Entry> list = List.of(); String title = ""; int page; Entry entry; int qty = 1;
        Menu(Type t) { type = t; }
        @Override public Inventory getInventory() { return inv; }
    }

    private Economy eco;
    private File dataFile;
    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final Map<String, Double> base = new HashMap<>();
    private final Map<String, Double> price = new HashMap<>();
    private final Map<String, Double> last = new HashMap<>();
    private final Map<Cat, List<Entry>> byCat = new EnumMap<>(Cat.class);
    private final Random rng = new Random();
    private double volatility, reversion, minMult, maxMult, impact, spread, priceMult;

    // ---------------- lifecycle ----------------

    @Override
    public void onEnable() {
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            getLogger().severe("No Vault economy found (install EssentialsX or similar). Disabling.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        eco = rsp.getProvider();
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "prices.yml");
        loadAll();
        exportList();
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("market").setExecutor(this);
        getCommand("market").setTabCompleter(this);

        long ticks = (long) (getConfig().getDouble("update-minutes", 5) * 60 * 20);
        getServer().getScheduler().runTaskTimer(this, this::tickMarket, ticks, ticks);
    }

    @Override
    public void onDisable() {
        if (eco != null) savePrices();
    }

    // ---------------- loading ----------------

    private boolean excluded(Material m, Set<String> extra) {
        String n = m.name();
        if (extra.contains(n)) return true;
        for (String e : EXCLUDE) {
            if (e.equals("LIGHT") || e.equals("VAULT")) { if (n.equals(e)) return true; }
            else if (n.contains(e)) return true;
        }
        return false;
    }

    private boolean matches(String name, String pat) {
        if (pat.startsWith("^")) return name.startsWith(pat.substring(1));
        if (pat.endsWith("$")) return name.endsWith(pat.substring(0, pat.length() - 1));
        return name.contains(pat);
    }

    private double guessPrice(Material m) {
        String n = m.name();
        for (String s : EXACT) {
            int i = s.lastIndexOf('=');
            if (s.substring(0, i).equals(n)) return Double.parseDouble(s.substring(i + 1));
        }
        for (String s : RULES) {
            int i = s.lastIndexOf('=');
            if (matches(n, s.substring(0, i))) return Double.parseDouble(s.substring(i + 1));
        }
        return DEFAULT_PRICE;
    }

    private void loadAll() {
        reloadConfig();
        volatility = getConfig().getDouble("volatility", 0.08);
        reversion = getConfig().getDouble("reversion", 0.05);
        minMult = getConfig().getDouble("min-multiplier", 0.3);
        maxMult = getConfig().getDouble("max-multiplier", 3.0);
        impact = getConfig().getDouble("trade-impact", 0.0005);
        spread = getConfig().getDouble("spread", 0.10);
        priceMult = getConfig().getDouble("price-multiplier", 5.0);

        Set<String> extra = new HashSet<>();
        for (String s : getConfig().getStringList("exclude")) extra.add(s.toUpperCase());

        Map<String, Entry> found = new TreeMap<>();
        Map<String, Double> prices = new HashMap<>();

        if (getConfig().getBoolean("auto-add-all", true)) {
            for (Material m : Material.values()) {
                if (m.isLegacy() || !m.isItem() || m.isAir() || excluded(m, extra)) continue;
                double p = guessPrice(m);
                if (p <= 0) continue;
                found.put(m.name(), new Entry(m.name(), m, null));
                prices.put(m.name(), p * priceMult);
            }
        }
        ConfigurationSection items = getConfig().getConfigurationSection("items");
        if (items != null) {
            for (String key : items.getKeys(false)) {
                Material m = Material.matchMaterial(key);
                if (m == null) { getLogger().warning("Unknown item: " + key); continue; }
                found.put(m.name(), new Entry(m.name(), m, null));
                prices.put(m.name(), items.getDouble(key) * priceMult);
            }
        }
        ConfigurationSection sp = getConfig().getConfigurationSection("spawners");
        if (sp != null) {
            for (String key : sp.getKeys(false)) {
                EntityType t;
                try { t = EntityType.valueOf(key.toUpperCase()); }
                catch (IllegalArgumentException ex) { getLogger().warning("Unknown spawner mob: " + key); continue; }
                String k = "SPAWNER_" + t.name();
                found.put(k, new Entry(k, Material.SPAWNER, t));
                prices.put(k, sp.getDouble(key));
            }
        }

        YamlConfiguration saved = YamlConfiguration.loadConfiguration(dataFile);
        entries.clear(); base.clear(); price.clear(); last.clear(); byCat.clear();
        for (Cat c : Cat.values()) byCat.put(c, new ArrayList<>());
        for (Map.Entry<String, Entry> e : found.entrySet()) {
            String k = e.getKey();
            entries.put(k, e.getValue());
            base.put(k, prices.get(k));
            double p = saved.getDouble(k, prices.get(k));
            price.put(k, p);
            last.put(k, p);
            byCat.get(categorize(e.getValue())).add(e.getValue());
        }
        byCat.get(Cat.SPAWNERS).sort(Comparator.comparingDouble(en -> base.get(en.key)));
        getLogger().info("Loaded " + entries.size() + " shop items.");
    }

    private void savePrices() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, Double> e : price.entrySet()) y.set(e.getKey(), round(e.getValue()));
        try { y.save(dataFile); } catch (IOException ex) { getLogger().warning("Couldn't save prices: " + ex.getMessage()); }
    }

    private void exportList() {
        List<String> lines = new ArrayList<>();
        lines.add(String.format("%-40s %-24s %12s %12s %12s", "ITEM", "CATEGORY", "BASE", "BUY", "SELL"));
        for (Cat c : Cat.values())
            for (Entry e : byCat.get(c))
                lines.add(String.format("%-40s %-24s %12.2f %12.2f %12.2f", e.key, c.label, base.get(e.key), buyPrice(e.key), sellPrice(e.key)));
        try { Files.write(new File(getDataFolder(), "items.txt").toPath(), lines); }
        catch (IOException ex) { getLogger().warning("Couldn't write items.txt: " + ex.getMessage()); }
    }

    // ---------------- market ----------------

    private void tickMarket() {
        for (String k : entries.keySet()) {
            double b = base.get(k);
            double p = price.get(k);
            last.put(k, p);
            double shock = (rng.nextDouble() * 2 - 1) * volatility;
            double pull = (b - p) / b * reversion;
            p *= 1 + shock + pull;
            price.put(k, clamp(p, b * minMult, b * maxMult));
        }
        savePrices();
        getServer().broadcastMessage("§e[Shop] §7Market prices updated! Open §f/market §7to trade.");
    }

    private double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private int clampInt(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private double round(double v) { return Math.round(v * 100.0) / 100.0; }
    private String fmt(double v) { return String.format("%,.2f", v); }
    private double buyPrice(String k) { return Math.max(0.01, round(price.get(k) * (1 + spread))); }
    private double sellPrice(String k) { return Math.max(0.01, round(price.get(k) * (1 - spread))); }

    private double changePct(String k) {
        double l = last.get(k);
        return l == 0 ? 0 : (price.get(k) - l) / l * 100;
    }

    private String arrow(String k) {
        double pct = changePct(k);
        if (Math.abs(pct) < 0.05) return "§7-";
        return (pct > 0 ? "§a▲ +" : "§c▼ ") + String.format("%.1f%%", pct);
    }

    private void movePrice(String k, int amount, boolean buying) {
        double b = base.get(k);
        double factor = Math.pow(1 + (buying ? impact : -impact), amount);
        price.put(k, clamp(price.get(k) * factor, b * minMult, b * maxMult));
    }

    // ---------------- item building ----------------

    private String nice(String s) {
        StringBuilder sb = new StringBuilder();
        for (String w : s.toLowerCase().split("_")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    private String title(Entry e) {
        return e.isSpawner() ? nice(e.spawner.name()) + " Spawner" : nice(e.mat.name());
    }

    private ItemStack spawnerItem(EntityType t, int amt) {
        ItemStack is = new ItemStack(Material.SPAWNER, amt);
        BlockStateMeta bsm = (BlockStateMeta) is.getItemMeta();
        CreatureSpawner cs = (CreatureSpawner) bsm.getBlockState();
        cs.setSpawnedType(t);
        bsm.setBlockState(cs);
        bsm.setDisplayName("§r§e" + nice(t.name()) + " Spawner");
        is.setItemMeta(bsm);
        return is;
    }

    private ItemStack[] stacksFor(Entry e, int amt) {
        int max = e.isSpawner() ? 64 : e.mat.getMaxStackSize();
        List<ItemStack> list = new ArrayList<>();
        while (amt > 0) {
            int n = Math.min(max, amt);
            list.add(e.isSpawner() ? spawnerItem(e.spawner, n) : new ItemStack(e.mat, n));
            amt -= n;
        }
        return list.toArray(new ItemStack[0]);
    }

    private ItemStack build(Entry e, int amt, String name, List<String> lore) {
        ItemStack is = e.isSpawner() ? spawnerItem(e.spawner, amt) : new ItemStack(e.mat, amt);
        ItemMeta meta = is.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.values());
        is.setItemMeta(meta);
        return is;
    }

    private ItemStack named(Material m, int amt, String name, String... lore) {
        ItemStack is = new ItemStack(m, amt);
        ItemMeta meta = is.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(Arrays.asList(lore));
        meta.addItemFlags(ItemFlag.values());
        is.setItemMeta(meta);
        return is;
    }

    private ItemStack pane() { return named(Material.GRAY_STAINED_GLASS_PANE, 1, " "); }

    private void fill(Inventory inv) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane());
    }

    private ItemStack browseIcon(Entry e) {
        List<String> l = new ArrayList<>();
        l.add("§7Buy: §e$" + fmt(buyPrice(e.key)));
        l.add(e.isSpawner() ? "§8Can't be sold back" : "§7Sell: §e$" + fmt(sellPrice(e.key)));
        l.add("§7Trend: " + arrow(e.key));
        l.add("");
        l.add("§aClick to choose an amount");
        return build(e, 1, "§f" + title(e), l);
    }

    private ItemStack balanceIcon(Player p) {
        return named(Material.GOLD_INGOT, 1, "§6Balance: §e$" + fmt(eco.getBalance(p)));
    }

    // ---------------- menus ----------------

    private void later(Runnable r) { getServer().getScheduler().runTask(this, r); }

    private void openMain(Player p) {
        Menu m = new Menu(Type.MAIN);
        m.inv = Bukkit.createInventory(m, 27, "§8Shop");
        fill(m.inv);
        Cat[] cats = Cat.values();
        for (int i = 0; i < cats.length; i++) {
            Cat c = cats[i];
            m.inv.setItem(CAT_SLOTS[i], named(c.icon, 1, "§e" + c.label,
                "§7" + byCat.get(c).size() + " items", "", "§aClick to browse"));
        }
        m.inv.setItem(4, balanceIcon(p));

        List<String> keys = new ArrayList<>(entries.keySet());
        keys.sort((x, y) -> Double.compare(changePct(y), changePct(x)));
        List<String> lore = new ArrayList<>();
        for (int i = 0; i < Math.min(3, keys.size()); i++)
            lore.add("§a▲ " + title(entries.get(keys.get(i))) + " §7" + String.format("%+.1f%%", changePct(keys.get(i))));
        for (int i = 0; i < Math.min(3, keys.size()); i++) {
            String k = keys.get(keys.size() - 1 - i);
            lore.add("§c▼ " + title(entries.get(k)) + " §7" + String.format("%+.1f%%", changePct(k)));
        }
        m.inv.setItem(24, named(Material.COMPARATOR, 1, "§bMarket movers", lore.toArray(new String[0])));
        m.inv.setItem(26, named(Material.BARRIER, 1, "§cClose"));
        p.openInventory(m.inv);
    }

    private void openBrowse(Player p, List<Entry> list, String title, int page) {
        int per = 45;
        int pages = Math.max(1, (list.size() + per - 1) / per);
        page = clampInt(page, 0, pages - 1);
        Menu m = new Menu(Type.BROWSE);
        m.list = list; m.title = title; m.page = page;
        m.inv = Bukkit.createInventory(m, 54, "§8" + title + " §7(" + (page + 1) + "/" + pages + ")");
        for (int i = 0; i < per; i++) {
            int idx = page * per + i;
            if (idx < list.size()) m.inv.setItem(i, browseIcon(list.get(idx)));
        }
        for (int i = 45; i < 54; i++) m.inv.setItem(i, pane());
        m.inv.setItem(45, named(Material.ARROW, 1, "§eBack to categories"));
        if (page > 0) m.inv.setItem(47, named(Material.SPECTRAL_ARROW, 1, "§aPrevious page"));
        m.inv.setItem(49, balanceIcon(p));
        if (page < pages - 1) m.inv.setItem(51, named(Material.SPECTRAL_ARROW, 1, "§aNext page"));
        m.inv.setItem(53, named(Material.BARRIER, 1, "§cClose"));
        p.openInventory(m.inv);
    }

    private int cap(Entry e) { return e.isSpawner() ? 16 : 2304; }

    private int count(Player p, Material mat) {
        int have = 0;
        for (ItemStack it : p.getInventory().getContents()) if (it != null && it.getType() == mat) have += it.getAmount();
        return have;
    }

    private void openAmount(Player p, Menu parent, Entry e) {
        Menu m = new Menu(Type.AMOUNT);
        m.list = parent.list; m.title = parent.title; m.page = parent.page; m.entry = e; m.qty = 1;
        m.inv = Bukkit.createInventory(m, 27, "§8" + title(e));
        renderAmount(p, m);
        p.openInventory(m.inv);
    }

    private void renderAmount(Player p, Menu m) {
        Entry e = m.entry;
        Inventory inv = m.inv;
        fill(inv);
        int qty = m.qty;
        double buyTotal = round(buyPrice(e.key) * qty);
        double sellTotal = round(sellPrice(e.key) * qty);

        int[] d = {-64, -10, -1, 0, 1, 10, 64};
        for (int i = 0; i < d.length; i++) {
            if (d[i] == 0) continue;
            int a = Math.abs(d[i]);
            inv.setItem(10 + i, d[i] < 0
                ? named(Material.RED_CONCRETE, Math.min(64, a), "§c-" + a)
                : named(Material.LIME_CONCRETE, Math.min(64, a), "§a+" + a));
        }

        List<String> lore = new ArrayList<>();
        lore.add("§7Amount: §f" + qty);
        lore.add("§7Buy total: §e$" + fmt(buyTotal));
        if (e.isSpawner()) lore.add("§8Can't be sold back");
        else lore.add("§7Sell total: §e$" + fmt(sellTotal));
        lore.add("§7Trend: " + arrow(e.key));
        if (!e.isSpawner()) lore.add("§7You have: §f" + count(p, e.mat));
        inv.setItem(13, build(e, clampInt(qty, 1, 64), "§f" + title(e), lore));

        inv.setItem(4, balanceIcon(p));
        inv.setItem(19, named(Material.ARROW, 1, "§eBack"));
        inv.setItem(21, named(Material.EMERALD_BLOCK, 1, "§a§lConfirm buy",
            "§7Buy §f" + qty + " §7for §e$" + fmt(buyTotal)));
        if (e.isSpawner()) inv.setItem(23, named(Material.BARRIER, 1, "§7Can't be sold"));
        else inv.setItem(23, named(Material.GOLD_BLOCK, 1, "§6§lConfirm sell",
            "§7Sell §f" + Math.min(qty, count(p, e.mat)) + " §7for §e$" + fmt(round(sellPrice(e.key) * Math.min(qty, count(p, e.mat))))));
    }

    // ---------------- click handling ----------------

    @EventHandler
    public void onClick(InventoryClickEvent ev) {
        if (!(ev.getInventory().getHolder() instanceof Menu m)) return;
        ev.setCancelled(true);
        if (!(ev.getWhoClicked() instanceof Player p)) return;
        if (ev.getClickedInventory() == null || ev.getClickedInventory() != ev.getInventory()) return;
        int slot = ev.getRawSlot();
        switch (m.type) {
            case MAIN -> clickMain(p, slot);
            case BROWSE -> clickBrowse(p, m, slot);
            case AMOUNT -> clickAmount(p, m, slot);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent ev) {
        if (ev.getInventory().getHolder() instanceof Menu) ev.setCancelled(true);
    }

    private void clickMain(Player p, int slot) {
        if (slot == 26) { later(p::closeInventory); return; }
        Cat[] cats = Cat.values();
        for (int i = 0; i < CAT_SLOTS.length; i++) {
            if (CAT_SLOTS[i] != slot) continue;
            Cat c = cats[i];
            List<Entry> list = byCat.get(c);
            later(() -> openBrowse(p, list, c.label, 0));
            return;
        }
    }

    private void clickBrowse(Player p, Menu m, int slot) {
        if (slot < 45) {
            int idx = m.page * 45 + slot;
            if (idx < m.list.size()) {
                Entry e = m.list.get(idx);
                later(() -> openAmount(p, m, e));
            }
            return;
        }
        switch (slot) {
            case 45 -> later(() -> openMain(p));
            case 47 -> later(() -> openBrowse(p, m.list, m.title, m.page - 1));
            case 51 -> later(() -> openBrowse(p, m.list, m.title, m.page + 1));
            case 53 -> later(p::closeInventory);
            default -> { }
        }
    }

    private void clickAmount(Player p, Menu m, int slot) {
        int[] d = {-64, -10, -1, 0, 1, 10, 64};
        if (slot >= 10 && slot <= 16 && slot != 13) {
            m.qty = clampInt(m.qty + d[slot - 10], 1, cap(m.entry));
            renderAmount(p, m);
            return;
        }
        switch (slot) {
            case 19 -> later(() -> openBrowse(p, m.list, m.title, m.page));
            case 21 -> { buy(p, m.entry, m.qty); renderAmount(p, m); }
            case 23 -> { if (!m.entry.isSpawner()) { sell(p, m.entry, m.qty); renderAmount(p, m); } }
            default -> { }
        }
    }

    // ---------------- trading ----------------

    private void buy(Player p, Entry e, int qty) {
        double unit = buyPrice(e.key);
        double total = round(unit * qty);
        if (!eco.has(p, total)) { p.sendMessage("§cYou need $" + fmt(total) + "."); return; }

        Map<Integer, ItemStack> left = p.getInventory().addItem(stacksFor(e, qty));
        int notGiven = left.values().stream().mapToInt(ItemStack::getAmount).sum();
        int given = qty - notGiven;
        if (given <= 0) { p.sendMessage("§cYour inventory is full."); return; }

        double charge = round(unit * given);
        eco.withdrawPlayer(p, charge);
        movePrice(e.key, given, true);
        p.sendMessage("§aBought " + given + " " + title(e) + " for $" + fmt(charge) + ".");
        if (notGiven > 0) p.sendMessage("§eInventory filled up, so you were only charged for " + given + ".");
    }

    private void sell(Player p, Entry e, int qty) {
        int have = count(p, e.mat);
        if (have == 0) { p.sendMessage("§cYou don't have any " + title(e) + "."); return; }
        int amt = Math.min(qty, have);

        PlayerInventory inv = p.getInventory();
        int toRemove = amt;
        for (int i = 0; i < inv.getSize() && toRemove > 0; i++) {
            ItemStack it = inv.getItem(i);
            if (it == null || it.getType() != e.mat) continue;
            int take = Math.min(it.getAmount(), toRemove);
            it.setAmount(it.getAmount() - take);
            if (it.getAmount() <= 0) inv.setItem(i, null);
            toRemove -= take;
        }
        double total = round(sellPrice(e.key) * amt);
        eco.depositPlayer(p, total);
        movePrice(e.key, amt, false);
        p.sendMessage("§aSold " + amt + " " + title(e) + " for $" + fmt(total) + ".");
    }

    // ---------------- commands ----------------

    private Entry find(String s) {
        String key = s.toUpperCase().replace(' ', '_');
        Entry e = entries.get(key);
        if (e == null) e = entries.get("SPAWNER_" + key);
        return e;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length > 0 && (a[0].equalsIgnoreCase("export") || a[0].equalsIgnoreCase("reload"))) {
            if (!s.hasPermission("stockshop.admin")) { s.sendMessage("§cNo permission."); return true; }
            if (a[0].equalsIgnoreCase("export")) {
                exportList();
                s.sendMessage("§aWrote plugins/StockShop/items.txt (" + entries.size() + " items).");
            } else {
                savePrices(); loadAll(); exportList();
                s.sendMessage("§aReloaded " + entries.size() + " items.");
            }
            return true;
        }
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }

        if (a.length == 0) { openMain(p); return true; }

        switch (a[0].toLowerCase()) {
            case "search" -> {
                if (a.length < 2) { p.sendMessage("§cUsage: /market search <text>"); return true; }
                String raw = String.join(" ", Arrays.copyOfRange(a, 1, a.length));
                String q = raw.toUpperCase();
                String qk = q.replace(' ', '_');
                List<Entry> res = new ArrayList<>();
                for (Entry e : entries.values())
                    if (e.key.contains(qk) || title(e).toUpperCase().contains(q)) res.add(e);
                if (res.isEmpty()) p.sendMessage("§cNothing matches '" + raw + "'.");
                else openBrowse(p, res, "Search: " + raw, 0);
            }
            case "price" -> {
                if (a.length < 2) { p.sendMessage("§cUsage: /market price <item>"); return true; }
                Entry e = find(String.join(" ", Arrays.copyOfRange(a, 1, a.length)));
                if (e == null) { p.sendMessage("§cNot found. Try /market search <text>"); return true; }
                p.sendMessage("§f" + title(e) + " §7buy §e$" + fmt(buyPrice(e.key)) + " §7sell §e$"
                    + (e.isSpawner() ? "n/a" : fmt(sellPrice(e.key))) + " " + arrow(e.key));
            }
            default -> openMain(p);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return filter(List.of("search", "price", "export", "reload"), a[0]);
        if (a.length == 2 && a[0].equalsIgnoreCase("price")) {
            List<String> names = new ArrayList<>();
            for (String k : entries.keySet()) names.add(k.toLowerCase());
            List<String> out = filter(names, a[1]);
            return out.size() > 50 ? out.subList(0, 50) : out;
        }
        return List.of();
    }

    private List<String> filter(List<String> list, String prefix) {
        List<String> out = new ArrayList<>();
        for (String x : list) if (x.startsWith(prefix.toLowerCase())) out.add(x);
        return out;
    }
}
